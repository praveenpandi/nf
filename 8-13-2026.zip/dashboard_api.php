<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

error_reporting(E_ALL);
ini_set('display_errors', 0);

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'test';

$conn = @new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit;
}
$conn->set_charset('utf8mb4');

// 1. Distinct Providers
$sql_providers = "SELECT DISTINCT COALESCE(NULLIF(rendering_provider, ''), 'Unassigned') AS provider_name 
                  FROM nflua_account_receivable_of_08032026 
                  ORDER BY provider_name ASC";
$res_prov = $conn->query($sql_providers);
$providers_list = ['All'];
if ($res_prov) {
    while ($pr = $res_prov->fetch_assoc()) {
        if (!empty($pr['provider_name']) && $pr['provider_name'] !== 'All') {
            $providers_list[] = $pr['provider_name'];
        }
    }
}

// 2. Distinct Years
$sql_years = "SELECT DISTINCT YEAR(created_date) AS yr 
              FROM nflua_account_receivable_of_08032026 
              WHERE created_date IS NOT NULL AND created_date <> '0000-00-00' 
              ORDER BY yr ASC";
$res_yr = $conn->query($sql_years);
$years_list = [];
if ($res_yr) {
    while ($yr = $res_yr->fetch_assoc()) {
        if (!empty($yr['yr'])) {
            $years_list[] = (int)$yr['yr'];
        }
    }
}
if (empty($years_list)) $years_list = [2024, 2025, 2026];

// 3. Filter Parameters
$group_by = isset($_REQUEST['group_by']) ? trim($_REQUEST['group_by']) : 'month'; // 'year', 'month', 'week', 'custom'
$rendering_provider = isset($_REQUEST['rendering_provider']) ? trim($_REQUEST['rendering_provider']) : 'All';

$from_date = isset($_REQUEST['from_date']) ? trim($_REQUEST['from_date']) : '';
$to_date = isset($_REQUEST['to_date']) ? trim($_REQUEST['to_date']) : '';

// Year-wise parameters handling
if ($group_by === 'year') {
    $start_year = isset($_REQUEST['start_year']) ? (int)$_REQUEST['start_year'] : 0;
    $end_year = isset($_REQUEST['end_year']) ? (int)$_REQUEST['end_year'] : 0;

    if ($start_year > 0) $from_date = "$start_year-01-01";
    if ($end_year > 0) $to_date = "$end_year-12-31";
}

// Defaults if empty
if (empty($from_date)) $from_date = '2026-01-01';
if (empty($to_date)) $to_date = '2026-08-04';

// 4. Dynamic WHERE Clause
$where_clauses = ["created_date IS NOT NULL", "created_date <> '0000-00-00'"];

if (!empty($from_date)) {
    $from_escaped = $conn->real_escape_string($from_date);
    $where_clauses[] = "DATE(created_date) >= '$from_escaped'";
}
if (!empty($to_date)) {
    $to_escaped = $conn->real_escape_string($to_date);
    $where_clauses[] = "DATE(created_date) <= '$to_escaped'";
}
if ($rendering_provider !== 'All' && !empty($rendering_provider)) {
    $prov_escaped = $conn->real_escape_string($rendering_provider);
    $where_clauses[] = "rendering_provider = '$prov_escaped'";
}

$where_sql = "WHERE " . implode(" AND ", $where_clauses);

// 5. Dynamic Grouping SQL
if ($group_by === 'year') {
    $group_select = "YEAR(created_date) AS Period_Year, 0 AS Period_Sub, CAST(YEAR(created_date) AS CHAR) AS Period_Label";
    $group_by_sql = "GROUP BY YEAR(created_date) ORDER BY Period_Year ASC";
} else if ($group_by === 'week') {
    $group_select = "YEAR(created_date) AS Period_Year, WEEK(created_date, 1) AS Period_Sub, CONCAT(YEAR(created_date), ' W', LPAD(WEEK(created_date, 1), 2, '0')) AS Period_Label";
    $group_by_sql = "GROUP BY YEAR(created_date), WEEK(created_date, 1) ORDER BY Period_Year ASC, Period_Sub ASC";
} else {
    // Default: month
    $group_select = "YEAR(created_date) AS Period_Year, MONTH(created_date) AS Period_Sub, DATE_FORMAT(created_date, '%Y %b') AS Period_Label";
    $group_by_sql = "GROUP BY YEAR(created_date), MONTH(created_date) ORDER BY Period_Year ASC, Period_Sub ASC";
}

// 6. Overall Aggregates (Executive 15-Metric Query with Filters)
$from_escaped = !empty($from_date) ? $conn->real_escape_string($from_date) : '';
$to_escaped = !empty($to_date) ? $conn->real_escape_string($to_date) : '';
$prov_escaped = ($rendering_provider !== 'All' && !empty($rendering_provider)) ? $conn->real_escape_string($rendering_provider) : '';

$build_sub_where = function($provider_col = 'rendering_provider', $date_col = 'created_date') use ($from_escaped, $to_escaped, $prov_escaped) {
    $clauses = ["$date_col IS NOT NULL", "$date_col <> '0000-00-00'"];
    if (!empty($from_escaped)) {
        $clauses[] = "DATE($date_col) >= '$from_escaped'";
    }
    if (!empty($to_escaped)) {
        $clauses[] = "DATE($date_col) <= '$to_escaped'";
    }
    if (!empty($prov_escaped)) {
        $clauses[] = "$provider_col = '$prov_escaped'";
    }
    return "WHERE " . implode(" AND ", $clauses);
};

$w_charges = $build_sub_where('rendering_provider', 'created_date');
$w_trans   = $build_sub_where('rendering_provider', 'created_date');
$w_pay     = $build_sub_where('provider_name', 'created_date');
$w_ar      = $build_sub_where('rendering_provider', 'created_date');
$w_ar_old  = $build_sub_where('rendering_provider', 'created_date');

$sql_overall = "SELECT
    -- Total Charges
    (SELECT ROUND(IFNULL(SUM(charge_amount),0),2)
     FROM nflua_charges_by_created_date_20260803
     $w_charges
    ) AS Total_Charges,

    -- Insurance Payment
    (SELECT ROUND(IFNULL(SUM(insurance_payment),0),2)
     FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
     $w_trans
    ) AS Insurance_Payment,

    -- Patient Payment
    (SELECT ROUND(IFNULL(SUM(collected_amount),0),2)
     FROM nflua_paymentpatientpayments_20260803
     $w_pay
    ) AS Patient_Payment,

    -- Adjustment
    (SELECT ROUND(IFNULL(SUM(adjustment),0),2)
     FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
     $w_trans
    ) AS Adjustment,

    -- Write Off
    (SELECT ROUND(IFNULL(SUM(write_off),0),2)
     FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
     $w_trans
    ) AS Write_Off,

    -- Insurance AR
    (SELECT ROUND(IFNULL(SUM(insurance_balance),0),2)
     FROM nflua_account_receivable_of_08032026
     $w_ar
    ) AS Insurance_AR,

    -- Total Collections
    ROUND(
        (
            (SELECT IFNULL(SUM(insurance_payment),0)
             FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
             $w_trans)
            +
            (SELECT IFNULL(SUM(collected_amount),0)
             FROM nflua_paymentpatientpayments_20260803
             $w_pay)
        ),
        2
    ) AS Total_Collections,

    -- Number of DOS
    (
        SELECT COUNT(DISTINCT date_of_service)
        FROM nflua_charges_by_created_date_20260803
        $w_charges
    ) AS Number_of_DOS,

    -- Average Daily Charges
    ROUND(
        (
            SELECT IFNULL(SUM(charge_amount),0)
            FROM nflua_charges_by_created_date_20260803
            $w_charges
        )
        /
        NULLIF(
            (
                SELECT COUNT(DISTINCT date_of_service)
                FROM nflua_charges_by_created_date_20260803
                $w_charges
            ),
            0
        ),
        2
    ) AS Average_Daily_Charges,

    -- Collection Rate
    ROUND(
        (
            (
                (SELECT IFNULL(SUM(insurance_payment),0)
                 FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
                 $w_trans)
                +
                (SELECT IFNULL(SUM(collected_amount),0)
                 FROM nflua_paymentpatientpayments_20260803
                 $w_pay)
            )
            /
            NULLIF(
                (
                    SELECT IFNULL(SUM(charge_amount),0)
                    FROM nflua_charges_by_created_date_20260803
                    $w_charges
                ),
                0
            )
        ) * 100,
        2
    ) AS Collection_Rate,

    -- Denied Claims
    (
        SELECT COUNT(DISTINCT charge_id)
        FROM nflua_account_receivable_of_08032026
        $w_ar
          AND insurance_balance <> 0
          AND insurance_payment = 0
          AND DATEDIFF(CURDATE(), date_of_service) >= 60
    ) AS Denied_Claims,

    -- Total Claims Submitted
    (
        SELECT COUNT(DISTINCT charge_id)
        FROM nflua_charges_by_created_date_20260803
        $w_charges
    ) AS Total_Claims_Submitted,

    -- Denial Rate
    ROUND(
        (
            (
                SELECT COUNT(DISTINCT charge_id)
                FROM nflua_account_receivable_of_08032026
                $w_ar
                  AND insurance_balance <> 0
                  AND insurance_payment = 0
                  AND DATEDIFF(CURDATE(), date_of_service) >= 60
            )
            /
            NULLIF(
                (
                    SELECT COUNT(DISTINCT charge_id)
                    FROM nflua_charges_by_created_date_20260803
                    $w_charges
                ),
                0
            )
        ) * 100,
        2
    ) AS Denial_Rate,

    -- Claims Paid on First Submission
    (
        SELECT COUNT(DISTINCT charge_id)
        FROM nflua_account_rec_20260803_not_to_use
        $w_ar_old
          AND date_of_service IS NOT NULL
          AND created_date IS NOT NULL
          AND DATEDIFF(created_date, date_of_service) <= 30
          AND insurance_payment > 0
    ) AS Claims_Paid_On_First_Submission,

    -- First Pass Resolution Rate (FPRR)
    ROUND(
        (
            (
                SELECT COUNT(DISTINCT charge_id)
                FROM nflua_account_rec_20260803_not_to_use
                $w_ar_old
                  AND date_of_service IS NOT NULL
                  AND created_date IS NOT NULL
                  AND DATEDIFF(created_date, date_of_service) <= 30
                  AND insurance_payment > 0
            )
            /
            NULLIF(
                (
                    SELECT COUNT(DISTINCT charge_id)
                    FROM nflua_charges_by_created_date_20260803
                    $w_charges
                ),
                0
            )
        ) * 100,
        2
    ) AS First_Pass_Resolution_Rate";

$res_overall = $conn->query($sql_overall);
$ov = $res_overall ? $res_overall->fetch_assoc() : [];

$total_charges = (float)($ov['Total_Charges'] ?? 0);
$ins_payment = (float)($ov['Insurance_Payment'] ?? 0);
$pat_payment = (float)($ov['Patient_Payment'] ?? 0);
$total_collections = (float)($ov['Total_Collections'] ?? 0);
$adjustments = (float)($ov['Adjustment'] ?? 0);
$write_offs = (float)($ov['Write_Off'] ?? 0);
$ins_balance = (float)($ov['Insurance_AR'] ?? 0);
$pat_balance = 0;
$total_ar = $ins_balance;
$procedure_payment = $ins_payment + $pat_payment;

$total_claims = (int)($ov['Total_Claims_Submitted'] ?? 0);
$denied_claims = (int)($ov['Denied_Claims'] ?? 0);
$first_pass_claims = (int)($ov['Claims_Paid_On_First_Submission'] ?? 0);

$net_charges = $total_charges - $adjustments;
$net_collection_ratio = $net_charges > 0 ? round(($total_collections / $net_charges) * 100, 2) : 0;
$gross_collection_ratio = (float)($ov['Collection_Rate'] ?? 0);
$collection_rate = $gross_collection_ratio;

$avg_daily_charges = (float)($ov['Average_Daily_Charges'] ?? 0);
$ar_days = $avg_daily_charges > 0 ? round($ins_balance / $avg_daily_charges, 1) : 0;

$denial_rate = (float)($ov['Denial_Rate'] ?? 0);
$fprr = (float)($ov['First_Pass_Resolution_Rate'] ?? 0);

$pct_ar_60_90 = 0;
$pct_ar_90_120 = 0;
$pct_ar_120_plus = 0;

$opening_ar_val = (float)($ov['Opening_AR'] ?? 0);
$closing_ar_val = (float)($ov['Insurance_AR'] ?? 0);

if ($opening_ar_val > 0) {
    $opening_ar = $opening_ar_val;
} else {
    $opening_ar = $closing_ar_val * 0.9;
}
$closing_ar = $closing_ar_val;
$avg_ar = round(($opening_ar + $closing_ar) / 2, 2);

// 7. Overall Top CPT Codes by Revenue (Charges)
$sql_top_cpt = "SELECT 
    COALESCE(NULLIF(procedure_code, ''), 'N/A') AS CPT_Code,
    COUNT(*) AS Total_Units,
    ROUND(SUM(CAST(NULLIF(charge_amount, '') AS DECIMAL(15,2))), 2) AS Total_Charges,
    ROUND(SUM(CAST(NULLIF(insurance_payment, '') AS DECIMAL(15,2))), 2) AS Insurance_Paid,
    ROUND(SUM(CAST(NULLIF(patient_payment, '') AS DECIMAL(15,2))), 2) AS Patient_Paid,
    ROUND(SUM(CAST(NULLIF(insurance_payment, '') AS DECIMAL(15,2)) + CAST(NULLIF(patient_payment, '') AS DECIMAL(15,2))), 2) AS Total_Collections,
    ROUND(SUM(CAST(NULLIF(total_balance, '') AS DECIMAL(15,2))), 2) AS Balance
FROM nflua_account_receivable_of_08032026
$where_sql
GROUP BY procedure_code
ORDER BY Total_Charges DESC
LIMIT 10";

$res_top_cpt = $conn->query($sql_top_cpt);
$top_cpt_revenue = [];
if ($res_top_cpt) {
    while ($r = $res_top_cpt->fetch_assoc()) {
        $chg = (float)$r['Total_Charges'];
        $pct = $total_charges > 0 ? round(($chg / $total_charges) * 100, 2) : 0;
        $top_cpt_revenue[] = [
            'CPT_Code' => $r['CPT_Code'],
            'Total_Units' => (int)$r['Total_Units'],
            'Total_Charges' => $chg,
            'Insurance_Paid' => (float)$r['Insurance_Paid'],
            'Patient_Paid' => (float)$r['Patient_Paid'],
            'Total_Collections' => (float)$r['Total_Collections'],
            'Balance' => (float)$r['Balance'],
            'Pct_Share' => $pct
        ];
    }
}

// 8. Grouped Insurance Payment Analysis
$sql_ins_month = "SELECT 
    $group_select,
    ROUND(SUM(CAST(NULLIF(insurance_payment, '') AS DECIMAL(15,2))), 2) AS Total_Insurance_Payment,
    COUNT(CASE WHEN CAST(NULLIF(insurance_payment, '') AS DECIMAL(15,2)) > 0 THEN 1 END) AS Paid_Claims_Count
FROM nflua_account_receivable_of_08032026
$where_sql
$group_by_sql";

$res_ins = $conn->query($sql_ins_month);
$monthwise_insurance = [];
if ($res_ins) {
    while ($r = $res_ins->fetch_assoc()) {
        $monthwise_insurance[] = [
            'Year' => (int)$r['Period_Year'],
            'Month_No' => (int)$r['Period_Sub'],
            'Month_Year' => $r['Period_Label'],
            'Total_Insurance_Payment' => (float)$r['Total_Insurance_Payment'],
            'Paid_Claims_Count' => (int)$r['Paid_Claims_Count']
        ];
    }
}

// 9. Grouped Patient Payment Analysis
$sql_pat_month = "SELECT 
    $group_select,
    ROUND(SUM(CAST(NULLIF(patient_payment, '') AS DECIMAL(15,2))), 2) AS Total_Patient_Payment,
    COUNT(CASE WHEN CAST(NULLIF(patient_payment, '') AS DECIMAL(15,2)) > 0 THEN 1 END) AS Paid_Patients_Count
FROM nflua_account_receivable_of_08032026
$where_sql
$group_by_sql";

$res_pat = $conn->query($sql_pat_month);
$monthwise_patient = [];
if ($res_pat) {
    while ($r = $res_pat->fetch_assoc()) {
        $monthwise_patient[] = [
            'Year' => (int)$r['Period_Year'],
            'Month_No' => (int)$r['Period_Sub'],
            'Month_Year' => $r['Period_Label'],
            'Total_Patient_Payment' => (float)$r['Total_Patient_Payment'],
            'Paid_Patients_Count' => (int)$r['Paid_Patients_Count']
        ];
    }
}

// 10. Grouped CPT Code Analysis
$sql_cpt_month = "SELECT 
    $group_select,
    COALESCE(NULLIF(procedure_code, ''), 'N/A') AS CPT_Code,
    COUNT(*) AS Total_Units,
    ROUND(SUM(CAST(NULLIF(charge_amount, '') AS DECIMAL(15,2))), 2) AS Total_Charges,
    ROUND(SUM(CAST(NULLIF(insurance_payment, '') AS DECIMAL(15,2))), 2) AS Insurance_Paid,
    ROUND(SUM(CAST(NULLIF(patient_payment, '') AS DECIMAL(15,2))), 2) AS Patient_Paid,
    ROUND(SUM(CAST(NULLIF(total_balance, '') AS DECIMAL(15,2))), 2) AS Balance
FROM nflua_account_receivable_of_08032026
$where_sql
GROUP BY Period_Year, Period_Sub, procedure_code
ORDER BY Period_Year DESC, Period_Sub DESC, Total_Charges DESC";

$res_cpt = $conn->query($sql_cpt_month);
$monthwise_cpt = [];
if ($res_cpt) {
    while ($r = $res_cpt->fetch_assoc()) {
        $monthwise_cpt[] = [
            'Year' => (int)$r['Period_Year'],
            'Month_No' => (int)$r['Period_Sub'],
            'Month_Year' => $r['Period_Label'],
            'CPT_Code' => $r['CPT_Code'],
            'Total_Units' => (int)$r['Total_Units'],
            'Total_Charges' => (float)$r['Total_Charges'],
            'Insurance_Paid' => (float)$r['Insurance_Paid'],
            'Patient_Paid' => (float)$r['Patient_Paid'],
            'Balance' => (float)$r['Balance']
        ];
    }
}

// 11. Grouped Location Name Analysis
$sql_loc_month = "SELECT 
    $group_select,
    COALESCE(NULLIF(location_name, ''), 'Unknown Location') AS Location_Name,
    COUNT(*) AS Total_Claims,
    ROUND(SUM(CAST(NULLIF(charge_amount, '') AS DECIMAL(15,2))), 2) AS Total_Charges,
    ROUND(SUM(CAST(NULLIF(insurance_payment, '') AS DECIMAL(15,2)) + CAST(NULLIF(patient_payment, '') AS DECIMAL(15,2))), 2) AS Total_Collections
FROM nflua_account_receivable_of_08032026
$where_sql
GROUP BY Period_Year, Period_Sub, location_name
ORDER BY Period_Year DESC, Period_Sub DESC, Total_Charges DESC";

$res_loc = $conn->query($sql_loc_month);
$monthwise_location = [];
if ($res_loc) {
    while ($r = $res_loc->fetch_assoc()) {
        $monthwise_location[] = [
            'Year' => (int)$r['Period_Year'],
            'Month_No' => (int)$r['Period_Sub'],
            'Month_Year' => $r['Period_Label'],
            'Location_Name' => $r['Location_Name'],
            'Total_Claims' => (int)$r['Total_Claims'],
            'Total_Charges' => (float)$r['Total_Charges'],
            'Total_Collections' => (float)$r['Total_Collections']
        ];
    }
}

// 12. Grouped Charge vs Collections Analysis
$sql_cvc_month = "SELECT 
    $group_select,
    ROUND(SUM(CAST(NULLIF(charge_amount, '') AS DECIMAL(15,2))), 2) AS Total_Charges,
    ROUND(SUM(CAST(NULLIF(insurance_payment, '') AS DECIMAL(15,2))), 2) AS Insurance_Collections,
    ROUND(SUM(CAST(NULLIF(patient_payment, '') AS DECIMAL(15,2))), 2) AS Patient_Collections,
    ROUND(SUM(CAST(NULLIF(insurance_payment, '') AS DECIMAL(15,2)) + CAST(NULLIF(patient_payment, '') AS DECIMAL(15,2))), 2) AS Total_Collections,
    ROUND(SUM(CAST(NULLIF(adjustment, '') AS DECIMAL(15,2))), 2) AS Adjustments
FROM nflua_account_receivable_of_08032026
$where_sql
$group_by_sql";

$res_cvc = $conn->query($sql_cvc_month);
$monthwise_cvc = [];
if ($res_cvc) {
    while ($r = $res_cvc->fetch_assoc()) {
        $chg = (float)$r['Total_Charges'];
        $coll = (float)$r['Total_Collections'];
        $adj = (float)$r['Adjustments'];
        $net_chg = $chg - $adj;
        $gross_rate = $chg > 0 ? round(($coll / $chg) * 100, 2) : 0;
        $net_rate = $net_chg > 0 ? round(($coll / $net_chg) * 100, 2) : 0;

        $monthwise_cvc[] = [
            'Year' => (int)$r['Period_Year'],
            'Month_No' => (int)$r['Period_Sub'],
            'Month_Year' => $r['Period_Label'],
            'Total_Charges' => $chg,
            'Insurance_Collections' => (float)$r['Insurance_Collections'],
            'Patient_Collections' => (float)$r['Patient_Collections'],
            'Total_Collections' => $coll,
            'Adjustments' => $adj,
            'Gross_Collection_Rate' => $gross_rate,
            'Net_Collection_Rate' => $net_rate
        ];
    }
}

$response = [
    'status' => 'success',
    'timestamp' => date('Y-m-d H:i:s'),
    'filter_params' => [
        'from_date' => $from_date,
        'to_date' => $to_date,
        'rendering_provider' => $rendering_provider,
        'group_by' => $group_by
    ],
    'providers' => array_values($providers_list),
    'years' => array_values($years_list),
    'financial_metrics' => [
        'total_charges' => round($total_charges, 2),
        'total_insurance_collections' => round($ins_payment, 2),
        'total_patient_collections' => round($pat_payment, 2),
        'total_collections' => round($total_collections, 2),
        'insurance_paid' => round($ins_payment, 2),
        'patient_paid' => round($pat_payment, 2),
        'contractual_adjustments' => round($adjustments, 2),
        'write_off_amount' => round($write_offs, 2),
        'outstanding_ar' => round($ins_balance, 2),
        'procedure_payment' => round($procedure_payment, 2)
    ],
    'kpis' => [
        'net_collection_ratio' => $net_collection_ratio,
        'gross_collection_ratio' => $gross_collection_ratio,
        'collection_rate' => $collection_rate,
        'avg_daily_charges' => round($avg_daily_charges, 2),
        'ar_days' => $ar_days,
        'denial_rate' => $denial_rate,
        'first_pass_resolution_rate' => $fprr,
        'pct_ar_60_90' => $pct_ar_60_90,
        'pct_ar_90_120' => $pct_ar_90_120,
        'pct_ar_120_plus' => $pct_ar_120_plus,
        'average_ar' => $avg_ar,
        'ar_aging_amounts' => [
            'ar_0_30' => round($ar_0_30, 2),
            'ar_31_60' => round($ar_31_60, 2),
            'ar_60_90' => round($ar_60_90, 2),
            'ar_90_120' => round($ar_90_120, 2),
            'ar_120_plus' => round($ar_120_plus, 2),
            'total_ar' => round($total_ar, 2)
        ]
    ],
    'top_cpt_revenue' => $top_cpt_revenue,
    'monthwise_insurance' => $monthwise_insurance,
    'monthwise_patient' => $monthwise_patient,
    'monthwise_cpt' => $monthwise_cpt,
    'monthwise_location' => $monthwise_location,
    'monthwise_cvc' => $monthwise_cvc
];

echo json_encode($response, JSON_PRETTY_PRINT);
$conn->close();
