<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

error_reporting(E_ALL);
ini_set('display_errors', 0);

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'test';

$conn = @new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit;
}
$conn->set_charset('utf8mb4');

// Complete Query Definitions in Requested Order
$queries = [
    // 1. Charges Count by Created Date In 2026
    'charges_count_created' => "SELECT
        DATE_FORMAT(created_date, '%Y %b') AS Month_Year,
        rendering_provider,
        COUNT(*) AS Total_Charges
    FROM nflua_charges_by_created_date_20260803
    WHERE created_date IS NOT NULL
      AND created_date <> '0000-00-00'
      AND YEAR(created_date) = 2026
      AND UPPER(tf) = 'FALSE'
    GROUP BY
        YEAR(created_date),
        MONTH(created_date),
        rendering_provider
    ORDER BY
        YEAR(created_date) ASC,
        MONTH(created_date) ASC,
        rendering_provider ASC",

    // 2. Charges $ Value by Created Date In 2026
    'charges_value_created' => "SELECT
        DATE_FORMAT(created_date, '%Y %b') AS Month_Year,
        rendering_provider,
        ROUND(SUM(charge_amount), 2) AS Total_Charge
    FROM nflua_charges_by_created_date_20260803
    WHERE created_date IS NOT NULL
      AND created_date <> '0000-00-00'
      AND YEAR(created_date) = 2026
    GROUP BY
        YEAR(created_date),
        MONTH(created_date),
        rendering_provider
    ORDER BY
        YEAR(created_date) ASC,
        MONTH(created_date) ASC,
        rendering_provider ASC",

    // 3. Location wise analysis by Created Date In 2026
    'charges_by_location_created' => "SELECT
    rendering_provider,
    location_name,

    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 1 THEN charge_id END) AS Jan,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 2 THEN charge_id END) AS Feb,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 3 THEN charge_id END) AS Mar,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 4 THEN charge_id END) AS Apr,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 5 THEN charge_id END) AS May,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 6 THEN charge_id END) AS Jun,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 7 THEN charge_id END) AS Jul,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 8 THEN charge_id END) AS Aug,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 9 THEN charge_id END) AS Sep,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 10 THEN charge_id END) AS Oct,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 11 THEN charge_id END) AS Nov,
    COUNT(DISTINCT CASE WHEN MONTH(created_date) = 12 THEN charge_id END) AS `Dec`,

    (
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 1 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 2 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 3 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 4 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 5 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 6 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 7 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 8 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 9 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 10 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 11 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(created_date) = 12 THEN charge_id END)
    ) AS Total

FROM nflua_charges_by_created_date_20260803
WHERE created_date IS NOT NULL
  AND created_date <> '0000-00-00'
  AND YEAR(created_date) = 2026
GROUP BY
    rendering_provider,
    location_name;",

    // 4. Charges Count by Date of Service In 2026
    'charges_count_dos' => "SELECT
        DATE_FORMAT(date_of_service, '%Y %b') AS Month_Year,
        rendering_provider,
        COUNT(*) AS Total_Charges
    FROM nflua_charges_by_created_date_20260803
    WHERE date_of_service IS NOT NULL
      AND date_of_service <> '0000-00-00'
      AND YEAR(date_of_service) = 2026
      AND UPPER(tf) = 'FALSE'
    GROUP BY
        YEAR(date_of_service),
        MONTH(date_of_service),
        rendering_provider
    ORDER BY
        YEAR(date_of_service) ASC,
        MONTH(date_of_service) ASC,
        rendering_provider ASC",

    // 5. Charges $ Value by Date of Service In 2026
    'charges_value_dos' => "SELECT
        DATE_FORMAT(date_of_service, '%Y %b') AS Month_Year,
        rendering_provider,
        ROUND(SUM(charge_amount), 2) AS Total_Charge
    FROM nflua_charges_by_created_date_20260803
    WHERE date_of_service IS NOT NULL
      AND date_of_service <> '0000-00-00'
      AND YEAR(date_of_service) = 2026
    GROUP BY
        YEAR(date_of_service),
        MONTH(date_of_service),
        rendering_provider
    ORDER BY
        YEAR(date_of_service) ASC,
        MONTH(date_of_service) ASC,
        rendering_provider ASC",

    // 6. Location Wise Analysis by Date of Service In 2026
    'charges_by_location_dos' => "SELECT
    rendering_provider,
    location_name,

    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 1 THEN charge_id END) AS Jan,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 2 THEN charge_id END) AS Feb,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 3 THEN charge_id END) AS Mar,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 4 THEN charge_id END) AS Apr,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 5 THEN charge_id END) AS May,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 6 THEN charge_id END) AS Jun,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 7 THEN charge_id END) AS Jul,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 8 THEN charge_id END) AS Aug,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 9 THEN charge_id END) AS Sep,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 10 THEN charge_id END) AS Oct,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 11 THEN charge_id END) AS Nov,
    COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 12 THEN charge_id END) AS `Dec`,

    (
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 1 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 2 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 3 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 4 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 5 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 6 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 7 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 8 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 9 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 10 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 11 THEN charge_id END) +
        COUNT(DISTINCT CASE WHEN MONTH(date_of_service) = 12 THEN charge_id END)
    ) AS Total

FROM nflua_charges_by_date_of_service_20260803
WHERE date_of_service IS NOT NULL
  AND date_of_service <> '0000-00-00'
  AND YEAR(date_of_service) = 2026
GROUP BY
    rendering_provider,
    location_name;",

    // 7. Insurance Payment Analysis month wise
    'insurance_payments' => "SELECT
        rendering_provider,
        YEAR(ledger_date) AS Year,
        MONTH(ledger_date) AS Month_No,
        DATE_FORMAT(ledger_date, '%Y %b') AS Month_Year,
        ROUND(SUM(insurance_payment), 2) AS Total_Insurance_Payment
    FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
    WHERE ledger_date IS NOT NULL
      AND ledger_date <> '0000-00-00'
    GROUP BY
        rendering_provider,
        YEAR(ledger_date),
        MONTH(ledger_date)
    ORDER BY
        Year ASC,
        Month_No ASC,
        rendering_provider ASC",

    // 8. Patient Payment Analysis month wise
    'patient_payments' => "SELECT
        YEAR(created_date) AS Year,
        MONTH(created_date) AS Month_No,
        DATE_FORMAT(created_date, '%Y %b') AS Month_Year,
        ROUND(SUM(collected_amount), 2) AS Total_Patient_Payment
    FROM nflua_paymentpatientpayments_20260803
    WHERE created_date IS NOT NULL
      AND created_date <> '0000-00-00'
    GROUP BY YEAR(created_date), MONTH(created_date)
    ORDER BY Year ASC, Month_No ASC",

    // 9. Total Collections Analysis month wise
    'total_collections_monthwise' => "SELECT *
FROM (
    SELECT
        COALESCE(p.Year, i.Year) AS Year,
        COALESCE(p.Month_No, i.Month_No) AS Month_No,
        DATE_FORMAT(
            STR_TO_DATE(CONCAT(COALESCE(p.Year, i.Year), '-', COALESCE(p.Month_No, i.Month_No), '-01'), '%Y-%m-%d'),
            '%Y %b'
        ) AS Month_Year,

        ROUND(IFNULL(p.Patient_Payment, 0), 2) AS Patient_Payment,
        ROUND(IFNULL(i.Insurance_Payment, 0), 2) AS Insurance_Payment,
        ROUND(IFNULL(p.Patient_Payment, 0) + IFNULL(i.Insurance_Payment, 0), 2) AS Total_Collection

    FROM
    (
        SELECT
            YEAR(created_date) AS Year,
            MONTH(created_date) AS Month_No,
            SUM(collected_amount) AS Patient_Payment
        FROM nflua_paymentpatientpayments_20260803
        GROUP BY YEAR(created_date), MONTH(created_date)
    ) p

    LEFT JOIN
    (
        SELECT
            YEAR(created_date) AS Year,
            MONTH(created_date) AS Month_No,
            SUM(insurance_payment) AS Insurance_Payment
        FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
        GROUP BY YEAR(created_date), MONTH(created_date)
    ) i
    ON p.Year = i.Year
    AND p.Month_No = i.Month_No

    UNION

    SELECT
        i.Year,
        i.Month_No,
        DATE_FORMAT(
            STR_TO_DATE(CONCAT(i.Year, '-', i.Month_No, '-01'), '%Y-%m-%d'),
            '%Y-%b'
        ) AS Month_Year,

        ROUND(0, 2) AS Patient_Payment,
        ROUND(i.Insurance_Payment, 2) AS Insurance_Payment,
        ROUND(i.Insurance_Payment, 2) AS Total_Collection

    FROM
    (
        SELECT
            YEAR(created_date) AS Year,
            MONTH(created_date) AS Month_No,
            SUM(insurance_payment) AS Insurance_Payment
        FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
        GROUP BY YEAR(created_date), MONTH(created_date)
    ) i

    LEFT JOIN
    (
        SELECT
            YEAR(created_date) AS Year,
            MONTH(created_date) AS Month_No
        FROM nflua_paymentpatientpayments_20260803
        GROUP BY YEAR(created_date), MONTH(created_date)
    ) p
    ON p.Year = i.Year
    AND p.Month_No = i.Month_No

    WHERE p.Year IS NULL
) AS MonthlyReport

UNION ALL

SELECT
    NULL AS Year,
    NULL AS Month_No,
    'Grand Total' AS Month_Year,
    ROUND(SUM(Patient_Payment), 2) AS Patient_Payment,
    ROUND(SUM(Insurance_Payment), 2) AS Insurance_Payment,
    ROUND(SUM(Total_Collection), 2) AS Total_Collection
FROM (
    SELECT
        COALESCE(p.Year, i.Year) AS Year,
        COALESCE(p.Month_No, i.Month_No) AS Month_No,
        ROUND(IFNULL(p.Patient_Payment, 0), 2) AS Patient_Payment,
        ROUND(IFNULL(i.Insurance_Payment, 0), 2) AS Insurance_Payment,
        ROUND(IFNULL(p.Patient_Payment, 0) + IFNULL(i.Insurance_Payment, 0), 2) AS Total_Collection

    FROM
    (
        SELECT
            YEAR(created_date) AS Year,
            MONTH(created_date) AS Month_No,
            SUM(collected_amount) AS Patient_Payment
        FROM nflua_paymentpatientpayments_20260803
        GROUP BY YEAR(created_date), MONTH(created_date)
    ) p

    LEFT JOIN
    (
        SELECT
            YEAR(created_date) AS Year,
            MONTH(created_date) AS Month_No,
            SUM(insurance_payment) AS Insurance_Payment
        FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
        GROUP BY YEAR(created_date), MONTH(created_date)
    ) i
    ON p.Year = i.Year
    AND p.Month_No = i.Month_No

    UNION

    SELECT
        i.Year,
        i.Month_No,
        0,
        ROUND(i.Insurance_Payment, 2),
        ROUND(i.Insurance_Payment, 2)
    FROM
    (
        SELECT
            YEAR(created_date) AS Year,
            MONTH(created_date) AS Month_No,
            SUM(insurance_payment) AS Insurance_Payment
        FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
        GROUP BY YEAR(created_date), MONTH(created_date)
    ) i
    LEFT JOIN
    (
        SELECT
            YEAR(created_date) AS Year,
            MONTH(created_date) AS Month_No
        FROM nflua_paymentpatientpayments_20260803
        GROUP BY YEAR(created_date), MONTH(created_date)
    ) p
    ON p.Year = i.Year
    AND p.Month_No = i.Month_No
    WHERE p.Year IS NULL
) AS Totals

ORDER BY
    CASE WHEN Year IS NULL THEN 1 ELSE 0 END,
    Year,
    Month_No",

    // 10. Top 10 CPT Codes Analysis (from transaction grid)
    'top_10_cpt_codes' => "SELECT
        COALESCE(NULLIF(procedure_code, ''), 'N/A') AS CPT_Code,
        COUNT(DISTINCT claim_id) AS Total_Units,
        ROUND(SUM(CAST(NULLIF(charge, '') AS DECIMAL(15,2))), 2) AS Total_Charges,
        ROUND(SUM(insurance_payment), 2) AS Insurance_Paid,
        ROUND(SUM(patient_payment), 2) AS Patient_Paid,
        ROUND(SUM(insurance_payment + patient_payment), 2) AS Total_Collections
    FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
    WHERE procedure_code IS NOT NULL AND procedure_code <> ''
    GROUP BY procedure_code
    ORDER BY Insurance_Paid DESC
    LIMIT 10",

    // 11. Top 10 Insurance Payers (from transaction grid)
    'top_10_payers' => "SELECT
        COALESCE(NULLIF(payer_name, ''), 'Self-Pay / Unassigned') AS Payer_Name,
        COUNT(DISTINCT claim_id) AS Total_Claims,
        ROUND(SUM(CAST(NULLIF(charge, '') AS DECIMAL(15,2))), 2) AS Total_Charges,
        ROUND(SUM(insurance_payment), 2) AS Insurance_Payment,
        ROUND(SUM(patient_payment), 2) AS Patient_Payment,
        ROUND(SUM(insurance_payment + patient_payment), 2) AS Total_Collections
    FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
    WHERE payer_name IS NOT NULL AND payer_name <> ''
    GROUP BY payer_name
    ORDER BY Insurance_Payment DESC
    LIMIT 10",

    // 12. Outstanding A/R
    'outstanding_ar' => "SELECT
        'Current Outstanding A/R' AS Category,
        ROUND(SUM(CAST(NULLIF(total_balance, '') AS DECIMAL(15,2))), 2) AS Total_AR,
        ROUND(SUM(CAST(NULLIF(insurance_balance, '') AS DECIMAL(15,2))), 2) AS Insurance_AR,
        ROUND(SUM(CAST(NULLIF(patient_balance, '') AS DECIMAL(15,2))), 2) AS Patient_AR,
        ROUND(SUM(CASE WHEN CAST(NULLIF(ar_age_by_created_date, '') AS SIGNED) BETWEEN 0 AND 30 THEN CAST(NULLIF(total_balance, '') AS DECIMAL(15,2)) ELSE 0 END), 2) AS AR_0_30,
        ROUND(SUM(CASE WHEN CAST(NULLIF(ar_age_by_created_date, '') AS SIGNED) BETWEEN 31 AND 60 THEN CAST(NULLIF(total_balance, '') AS DECIMAL(15,2)) ELSE 0 END), 2) AS AR_31_60,
        ROUND(SUM(CASE WHEN CAST(NULLIF(ar_age_by_created_date, '') AS SIGNED) BETWEEN 61 AND 90 THEN CAST(NULLIF(total_balance, '') AS DECIMAL(15,2)) ELSE 0 END), 2) AS AR_61_90,
        ROUND(SUM(CASE WHEN CAST(NULLIF(ar_age_by_created_date, '') AS SIGNED) BETWEEN 91 AND 120 THEN CAST(NULLIF(total_balance, '') AS DECIMAL(15,2)) ELSE 0 END), 2) AS AR_91_120,
        ROUND(SUM(CASE WHEN CAST(NULLIF(ar_age_by_created_date, '') AS SIGNED) > 120 THEN CAST(NULLIF(total_balance, '') AS DECIMAL(15,2)) ELSE 0 END), 2) AS AR_120_Plus
    FROM nflua_account_receivable_of_08032026",

    // Legacy alias backwards compatibility
    'charges_count_dos_tbl' => "SELECT YEAR(date_of_service) AS Year, MONTH(date_of_service) AS Month_No, DATE_FORMAT(date_of_service, '%Y %b') AS Month_Year, COUNT(*) AS Total_Charges FROM nflua_charges_by_date_of_service_20260803 WHERE date_of_service IS NOT NULL AND date_of_service <> '0000-00-00' AND UPPER(tf) = 'FALSE' GROUP BY YEAR(date_of_service), MONTH(date_of_service) ORDER BY YEAR(date_of_service), MONTH(date_of_service)",
    'charges_value_dos_tbl' => "SELECT YEAR(date_of_service) AS Year, MONTH(date_of_service) AS Month_No, DATE_FORMAT(date_of_service, '%Y %b') AS Month_Year, ROUND(SUM(charge_amount), 2) AS Total_Charge FROM nflua_charges_by_date_of_service_20260803 WHERE date_of_service IS NOT NULL AND date_of_service <> '0000-00-00' GROUP BY YEAR(date_of_service), MONTH(date_of_service) ORDER BY YEAR(date_of_service), MONTH(date_of_service)",
    'charges_by_location' => "SELECT location_name AS `Row Labels`, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 1 THEN charge_id END) AS Jan, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 2 THEN charge_id END) AS Feb, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 3 THEN charge_id END) AS Mar, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 4 THEN charge_id END) AS Apr, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 5 THEN charge_id END) AS May, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 6 THEN charge_id END) AS Jun, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 7 THEN charge_id END) AS Jul, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 8 THEN charge_id END) AS Aug, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 9 THEN charge_id END) AS Sep, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 10 THEN charge_id END) AS Oct, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 11 THEN charge_id END) AS Nov, COUNT(DISTINCT CASE WHEN MONTH(created_date) = 12 THEN charge_id END) AS `Dec`, COUNT(DISTINCT charge_id) AS `Grand Total` FROM nflua_charges_by_created_date_20260803 WHERE created_date IS NOT NULL AND created_date <> '0000-00-00' AND YEAR(created_date) = 2026 GROUP BY location_name ORDER BY `Grand Total` DESC",
    'charges_by_dos' => "SELECT YEAR(date_of_service) AS Year, MONTH(date_of_service) AS Month_No, DATE_FORMAT(date_of_service, '%Y %b') AS Month_Year, ROUND(SUM(charge_amount), 2) AS Total_Charge FROM nflua_charges_by_created_date_20260803 WHERE date_of_service IS NOT NULL AND date_of_service <> '0000-00-00' GROUP BY YEAR(date_of_service), MONTH(date_of_service) ORDER BY YEAR(date_of_service), MONTH(date_of_service)",
    'appointment_analysis' => "SELECT YEAR(date_of_service) AS year, MONTH(date_of_service) AS month, COUNT(*) AS total_records FROM nflua_appointmentappointmentanalysisgrid_20260803 WHERE appointment_status IN ('Checked In', 'Checked Out', 'Confirmed', 'New') GROUP BY YEAR(date_of_service), MONTH(date_of_service) ORDER BY YEAR(date_of_service), MONTH(date_of_service)",
    'appt_level1' => "SELECT YEAR(date_of_service) AS Year, MONTH(date_of_service) AS Month_No, DATE_FORMAT(date_of_service,'%Y %b') AS Month_Year, COUNT(*) AS Total_Appointments FROM nflua_appointmentappointmentanalysisgrid_20260803 WHERE appointment_status IN ('Checked In', 'Checked Out', 'Confirmed', 'New') GROUP BY YEAR(date_of_service), MONTH(date_of_service) ORDER BY Year, Month_No",
    'appt_level2' => "SELECT YEAR(date_of_service) AS Year, MONTH(date_of_service) AS Month_No, DATE_FORMAT(date_of_service,'%Y %b') AS Month_Year, appointment_type, COUNT(*) AS Total_Appointments FROM nflua_appointmentappointmentanalysisgrid_20260803 WHERE appointment_status IN ('Checked In', 'Checked Out', 'Confirmed', 'New') GROUP BY YEAR(date_of_service), MONTH(date_of_service), appointment_type ORDER BY Year, Month_No, Total_Appointments DESC",
    'appt_level3' => "SELECT YEAR(date_of_service) AS Year, MONTH(date_of_service) AS Month_No, DATE_FORMAT(date_of_service,'%Y %b') AS Month_Year, appointment_type, patient_name, COUNT(*) AS Appointments, ROUND(SUM(copay), 2) AS Total_Copay, ROUND(AVG(copay), 2) AS Avg_Copay, ROUND(MAX(copay), 2) AS Highest_Copay FROM nflua_appointmentappointmentanalysisgrid_20260803 WHERE appointment_status IN ('Checked In', 'Checked Out', 'Confirmed', 'New') GROUP BY YEAR(date_of_service), MONTH(date_of_service), appointment_type, patient_name ORDER BY Total_Copay DESC",
    'appt_level4' => "SELECT YEAR(date_of_service) AS Year, MONTH(date_of_service) AS Month_No, DATE_FORMAT(date_of_service,'%Y %b') AS Month_Year, practice_name, COUNT(*) AS Total_Appointments FROM nflua_appointmentappointmentanalysisgrid_20260803 WHERE appointment_status IN ('Checked In', 'Checked Out', 'Confirmed', 'New') GROUP BY YEAR(date_of_service), MONTH(date_of_service), practice_name ORDER BY Year, Month_No, Total_Appointments DESC",
    'appt_level5' => "SELECT YEAR(date_of_service) AS Year, MONTH(date_of_service) AS Month_No, DATE_FORMAT(date_of_service,'%Y %b') AS Month_Year, practice_name, location_name, COUNT(*) AS Total_Appointments FROM nflua_appointmentappointmentanalysisgrid_20260803 WHERE appointment_status IN ('Checked In', 'Checked Out', 'Confirmed', 'New') GROUP BY YEAR(date_of_service), MONTH(date_of_service), practice_name, location_name ORDER BY Year, Month_No, Total_Appointments DESC",
    'missing_charges' => "SELECT location_name, YEAR(appointment_date) AS Year, MONTH(appointment_date) AS Month_No, DATE_FORMAT(appointment_date, '%Y %b') AS Month_Year, COUNT(*) AS Total_Missing_Charges FROM nflua_appointmentmissingchargesreport_20260803 WHERE appointment_date IS NOT NULL AND appointment_date <> '0000-00-00' AND non_charge = '' AND possible_match = '' GROUP BY location_name, YEAR(appointment_date), MONTH(appointment_date) ORDER BY Year ASC, Month_No ASC, location_name ASC"
];

$response = [
    'status' => 'success',
    'timestamp' => date('Y-m-d H:i:s'),
    'data' => []
];

foreach ($queries as $key => $sql) {
    $res = $conn->query($sql);
    $rows = [];
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            foreach ($r as $col => $val) {
                if (is_numeric($val) && strpos($col, 'Year') === false && strpos($col, 'year') === false && strpos($col, 'Month') === false && strpos($col, 'month') === false) {
                    $r[$col] = (float)$val == (int)$val ? (int)$val : (float)$val;
                } elseif (in_array($col, ['Year', 'year', 'Month_No', 'month', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Grand Total', 'Total', 'Total_Charges', 'total_records', 'Total_Records', 'Total_Appointments', 'Appointments'])) {
                    $r[$col] = (int)$val;
                }
            }
            $rows[] = $r;
        }
    }
    $response['data'][$key] = $rows;
}

// Aggregate summary metrics
$total_charges_cnt = 0;
foreach ($response['data']['charges_count_created'] as $r) {
    $total_charges_cnt += (int)($r['Total_Charges'] ?? 0);
}

$total_charges_amt = 0;
foreach ($response['data']['charges_value_created'] as $r) {
    $total_charges_amt += (float)($r['Total_Charge'] ?? 0);
}

$total_dos_amt = 0;
$dos_value_arr = $response['data']['charges_value_dos'] ?? $response['data']['charges_value_dos_tbl'] ?? [];
foreach ($dos_value_arr as $r) {
    $total_dos_amt += (float)($r['Total_Charge'] ?? 0);
}

$total_dos_cnt = 0;
$dos_cnt_arr = $response['data']['charges_count_dos'] ?? $response['data']['charges_count_dos_tbl'] ?? [];
foreach ($dos_cnt_arr as $r) {
    $total_dos_cnt += (int)($r['Total_Charges'] ?? 0);
}

$total_patient_pmt = 0;
foreach ($response['data']['patient_payments'] as $r) {
    $total_patient_pmt += (float)($r['Total_Patient_Payment'] ?? 0);
}

$total_insurance_pmt = 0;
foreach ($response['data']['insurance_payments'] as $r) {
    $total_insurance_pmt += (float)($r['Total_Insurance_Payment'] ?? 0);
}

$total_missing_charges = 0;
foreach ($response['data']['missing_charges'] as $r) {
    $total_missing_charges += (int)($r['Total_Missing_Charges'] ?? $r['Total_Records'] ?? 0);
}

$total_appointments = 0;
$appts_arr = $response['data']['appt_level1'] ?? $response['data']['appointment_analysis'] ?? [];
foreach ($appts_arr as $r) {
    $total_appointments += (int)($r['Total_Appointments'] ?? $r['total_records'] ?? 0);
}

$sql_exec = "SELECT
    -- Total Charges
    (SELECT ROUND(IFNULL(SUM(charge_amount),0),2)
     FROM nflua_charges_by_created_date_20260803
    ) AS Total_Charges,
 
    -- Insurance Payment
    (SELECT ROUND(IFNULL(SUM(insurance_payment),0),2)
     FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
    ) AS Insurance_Payment,
 
    -- Patient Payment
    (SELECT ROUND(IFNULL(SUM(collected_amount),0),2)
     FROM nflua_paymentpatientpayments_20260803
    ) AS Patient_Payment,
 
    -- Patient Balance
    (SELECT ROUND(IFNULL(SUM(CAST(NULLIF(patient_balance, '') AS DECIMAL(15,2))), 0), 2)
     FROM nflua_account_receivable_of_08032026
    ) AS Patient_Balance,

    -- Adjustment
    (SELECT ROUND(IFNULL(SUM(adjustment),0),2)
     FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
    ) AS Adjustment,
 
    -- Write Off
    (SELECT ROUND(IFNULL(SUM(write_off),0),2)
     FROM nflua_transactiontransactiondetailsanalysisgrid_20260803
    ) AS Write_Off,
 
    -- Insurance AR
    (SELECT ROUND(IFNULL(SUM(insurance_balance),0),2)
     FROM nflua_account_receivable_of_08032026
    ) AS Insurance_AR,
 
    -- Total Collections
    ROUND(
        (
            (SELECT IFNULL(SUM(insurance_payment),0)
             FROM nflua_transactiontransactiondetailsanalysisgrid_20260803)
            +
            (SELECT IFNULL(SUM(collected_amount),0)
             FROM nflua_paymentpatientpayments_20260803)
        ),
        2
    ) AS Total_Collections,
 
    -- Number of DOS
    (
        SELECT COUNT(DISTINCT date_of_service)
        FROM nflua_charges_by_created_date_20260803
    ) AS Number_of_DOS,
 
    -- Average Daily Charges
    ROUND(
        (
            SELECT IFNULL(SUM(charge_amount),0)
            FROM nflua_charges_by_created_date_20260803
        )
        /
        NULLIF(
            (
                SELECT COUNT(DISTINCT date_of_service)
                FROM nflua_charges_by_created_date_20260803
            ),
            0
        ),
        2
    ) AS Average_Daily_Charges,
 
    -- Collection Rate
    ROUND(
        (
            (
                (SELECT IFNULL(SUM(insurance_payment),0)
                 FROM nflua_transactiontransactiondetailsanalysisgrid_20260803)
                +
                (SELECT IFNULL(SUM(collected_amount),0)
                 FROM nflua_paymentpatientpayments_20260803)
            )
            /
            NULLIF(
                (
                    SELECT IFNULL(SUM(charge_amount),0)
                    FROM nflua_charges_by_created_date_20260803
                ),
                0
            )
        ) * 100,
        2
    ) AS Collection_Rate,

    -- Net Collection Ratio = ((Insurance Payment + Patient Payment + Patient Balance) / (Total Charges - Adjustment)) * 100
    ROUND(
        (
            (
                (SELECT IFNULL(SUM(insurance_payment),0) FROM nflua_transactiontransactiondetailsanalysisgrid_20260803)
                +
                (SELECT IFNULL(SUM(collected_amount),0) FROM nflua_paymentpatientpayments_20260803)
                +
                (SELECT IFNULL(SUM(CAST(NULLIF(patient_balance, '') AS DECIMAL(15,2))), 0) FROM nflua_account_receivable_of_08032026)
            )
            /
            NULLIF(
                (
                    (SELECT IFNULL(SUM(charge_amount),0) FROM nflua_charges_by_created_date_20260803)
                    -
                    (SELECT IFNULL(SUM(adjustment),0) FROM nflua_transactiontransactiondetailsanalysisgrid_20260803)
                ),
                0
            )
        ) * 100,
        2
    ) AS Net_Collection_Ratio,

    -- AR Days = Insurance AR / Average Daily Charges
    ROUND(
        (SELECT IFNULL(SUM(insurance_balance),0) FROM nflua_account_receivable_of_08032026)
        /
        NULLIF(
            (
                (SELECT IFNULL(SUM(charge_amount),0) FROM nflua_charges_by_created_date_20260803)
                /
                NULLIF((SELECT COUNT(DISTINCT date_of_service) FROM nflua_charges_by_created_date_20260803), 0)
            ),
            0
        ),
        1
    ) AS AR_Days,

    -- AR 120+ Days Amount
    (SELECT ROUND(IFNULL(SUM(CASE WHEN CAST(NULLIF(ar_age_by_created_date, '') AS SIGNED) > 120 THEN CAST(NULLIF(total_balance, '') AS DECIMAL(15,2)) ELSE 0 END), 0), 2)
     FROM nflua_account_receivable_of_08032026
    ) AS AR_120_Plus_Amount,

    -- AR 120+ Days % = (Outstanding AR 120+ Days / Total Insurance AR) * 100
    ROUND(
        (
            (SELECT IFNULL(SUM(CASE WHEN CAST(NULLIF(ar_age_by_created_date, '') AS SIGNED) > 120 THEN CAST(NULLIF(total_balance, '') AS DECIMAL(15,2)) ELSE 0 END), 0) FROM nflua_account_receivable_of_08032026)
            /
            NULLIF((SELECT IFNULL(SUM(insurance_balance), 0) FROM nflua_account_receivable_of_08032026), 0)
        ) * 100,
        2
    ) AS AR_120_Percent,
 
    -- Denied Claims
    (
        SELECT COUNT(DISTINCT charge_id)
        FROM nflua_account_receivable_of_08032026
        WHERE insurance_balance <> 0
          AND insurance_payment = 0
          AND DATEDIFF(CURDATE(), date_of_service) >= 60
    ) AS Denied_Claims,
 
    -- Total Claims Submitted
    (
        SELECT COUNT(DISTINCT charge_id)
        FROM nflua_charges_by_created_date_20260803
    ) AS Total_Claims_Submitted,
 
    -- Denial Rate
    ROUND(
        (
            (
                SELECT COUNT(DISTINCT charge_id)
                FROM nflua_account_receivable_of_08032026
                WHERE insurance_balance <> 0
                  AND insurance_payment = 0
                  AND DATEDIFF(CURDATE(), date_of_service) >= 60
            )
            /
            NULLIF(
                (
                    SELECT COUNT(DISTINCT charge_id)
                    FROM nflua_charges_by_created_date_20260803
                ),
                0
            )
        ) * 100,
        2
    ) AS Denial_Rate,
 
    -- Claims Paid on First Submission
    (
        SELECT COUNT(DISTINCT charge_id)
        FROM nflua_account_rec_20260803_not_to_use
        WHERE date_of_service IS NOT NULL
          AND created_date IS NOT NULL
          AND DATEDIFF(created_date, date_of_service) <= 30
          AND insurance_payment > 0
    ) AS Claims_Paid_On_First_Submission,
 
    -- First Pass Resolution Rate (FPRR)
    ROUND(
        (
            (
                SELECT COUNT(DISTINCT charge_id)
                FROM nflua_account_rec_20260803_not_to_use
                WHERE date_of_service IS NOT NULL
                  AND created_date IS NOT NULL
                  AND DATEDIFF(created_date, date_of_service) <= 30
                  AND insurance_payment > 0
            )
            /
            NULLIF(
                (
                    SELECT COUNT(DISTINCT charge_id)
                    FROM nflua_charges_by_created_date_20260803
                ),
                0
            )
        ) * 100,
        2
    ) AS First_Pass_Resolution_Rate";

$res_exec = $conn->query($sql_exec);
$exec_row = $res_exec ? $res_exec->fetch_assoc() : [];

$response['executive_metrics'] = [
    'Total_Charges' => (float)($exec_row['Total_Charges'] ?? 0),
    'Insurance_Payment' => (float)($exec_row['Insurance_Payment'] ?? 0),
    'Patient_Payment' => (float)($exec_row['Patient_Payment'] ?? 0),
    'Patient_Balance' => (float)($exec_row['Patient_Balance'] ?? 0),
    'Adjustment' => (float)($exec_row['Adjustment'] ?? 0),
    'Write_Off' => (float)($exec_row['Write_Off'] ?? 0),
    'Insurance_AR' => (float)($exec_row['Insurance_AR'] ?? 0),
    'Total_Collections' => (float)($exec_row['Total_Collections'] ?? 0),
    'Number_of_DOS' => (int)($exec_row['Number_of_DOS'] ?? 0),
    'Average_Daily_Charges' => (float)($exec_row['Average_Daily_Charges'] ?? 0),
    'Collection_Rate' => (float)($exec_row['Collection_Rate'] ?? 0),
    'Net_Collection_Ratio' => (float)($exec_row['Net_Collection_Ratio'] ?? 0),
    'AR_Days' => (float)($exec_row['AR_Days'] ?? 0),
    'AR_120_Plus_Amount' => (float)($exec_row['AR_120_Plus_Amount'] ?? 0),
    'AR_120_Percent' => (float)($exec_row['AR_120_Percent'] ?? 0),
    'Denied_Claims' => (int)($exec_row['Denied_Claims'] ?? 0),
    'Total_Claims_Submitted' => (int)($exec_row['Total_Claims_Submitted'] ?? 0),
    'Denial_Rate' => (float)($exec_row['Denial_Rate'] ?? 0),
    'Claims_Paid_On_First_Submission' => (int)($exec_row['Claims_Paid_On_First_Submission'] ?? 0),
    'First_Pass_Resolution_Rate' => (float)($exec_row['First_Pass_Resolution_Rate'] ?? 0)
];

$response['summary'] = [
    'total_charges_count' => $total_charges_cnt,
    'total_charges_amount' => round($total_charges_amt, 2),
    'total_dos_amount' => round($total_dos_amt, 2),
    'total_dos_count' => $total_dos_cnt,
    'total_patient_payment' => round($total_patient_pmt, 2),
    'total_insurance_payment' => round($total_insurance_pmt, 2),
    'total_missing_charges' => $total_missing_charges,
    'total_appointments' => $total_appointments,
    'locations_count' => count($response['data']['charges_by_location'])
];

echo json_encode($response, JSON_PRETTY_PRINT);
$conn->close();
